// src/screens/PiDashboardScreen.container.js

import React, { useState } from 'react';
import { View, ActivityIndicator } from 'react-native';
import PiDashboardScreenView from '../components/PiDashboardScreen.view';
import { useNetworks } from '../hooks/useNetworks';

export default function PiDashboardScreenContainer({ route }) {
  const { id, hostname, host } = route.params;

  // useNetworks now takes two args: piId and host
  const {
    creds,           // null until loaded
    curr,
    known,
    scan,
    refresh,
    scanNetworks,
    connect,
    forget,
    connectNew,
  } = useNetworks(id, host);

  const credsLoaded = creds !== null;

  // Local modal state
  const [modalVisible, setModalVisible] = useState(false);
  const [modalSsid, setModalSsid]       = useState('');
  const [modalPsk, setModalPsk]         = useState('');

  const showModal = (ssid) => {
    setModalSsid(ssid);
    setModalPsk('');
    setModalVisible(true);
  };
  const hideModal = () => setModalVisible(false);

  if (!credsLoaded) {
    return (
      <View style={{ flex:1, justifyContent:'center', alignItems:'center' }}>
        <ActivityIndicator size="large" />
      </View>
    );
  }

  return (
    <PiDashboardScreenView
      hostname={hostname}
      curr={curr}
      known={known}
      scan={scan}
      modalVisible={modalVisible}
      modalSsid={modalSsid}
      modalPsk={modalPsk}
      onScan={scanNetworks}
      onConnect={connect}
      onForget={forget}
      onConnectNew={connectNew}
      showModal={showModal}
      hideModal={hideModal}
      onChangeModalPsk={setModalPsk}
    />
  );
}
