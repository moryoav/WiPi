// src/hooks/useNetworks.js
import { useState, useEffect, useCallback } from 'react';
import { runSSH }   from '../lib/sshClient';
import { getPiCreds } from '../lib/storage';

/* ────────────────────────────────────────────────────────── helpers ── */

/** Parse `wpa_cli status` output into { key: value } */
function parseStatus(text = '') {
  const obj = {};
  text.split('\n').forEach(line => {
    const idx = line.indexOf('=');
    if (idx > 0) {
      const key = line.slice(0, idx).trim();
      const val = line.slice(idx + 1).trim();
      obj[key] = val;
    }
  });
  return obj;
}

/** Parse `wpa_cli list_networks` into [{ id, ssid, selected }] */
function parseNetworks(text = '') {
  const lines = text.trim().split('\n').filter(Boolean);
  if (lines.length <= 1) return [];
  return lines.slice(1).map(line => {
    const cols = line.split(/\s+/);
    const [id = '', ssid = ''] = cols;
    const flags = cols.slice(3).join(' ');
    return {
      id: id.trim(),
      ssid: ssid.trim(),
      selected: flags.includes('CURRENT'),
    };
  });
}

/* ────────────────────────────────────────────────────────── hook ──── */

export function useNetworks(piId, host) {
  const [creds, setCreds] = useState(null);
  const [curr,  setCurr]  = useState(null);
  const [known, setKnown] = useState([]);
  const [scan,  setScan]  = useState([]);

  /* 1️⃣  Load SSH credentials once */
  useEffect(() => {
    (async () => {
      try {
        const c = await getPiCreds(piId);
        setCreds({ host, ...c });
      } catch (err) {
        console.warn('Failed to load creds:', err);
      }
    })();
  }, [piId, host]);

  /* 2️⃣  Utility: run multiple commands in a single SSH session */
  const runPipeline = useCallback(async (cmds) => {
    if (!creds) throw new Error('SSH credentials not ready');
    const pipeline = cmds.join(' && ');
    for (let attempt = 1; attempt <= 2; attempt++) {
      try {
        return await runSSH({ ...creds, command: `bash -lc "${pipeline}"` });
      } catch (err) {
        if (attempt === 1 && /Connection reset/.test(err.message)) {
          await new Promise(r => setTimeout(r, 3000));  // brief back-off
          continue;
        }
        throw err;
      }
    }
  }, [creds]);

  /* 3️⃣  Refresh current + known networks */
  const refresh = useCallback(async () => {
    if (!creds) return;
    try {
      const out = await runPipeline([
        '/sbin/wpa_cli -i wlan2 status',
        'echo "__SPLIT__"',
        '/sbin/wpa_cli -i wlan2 list_networks',
      ]);
      const [statusTxt, netsTxt] = out.split('__SPLIT__');
      setCurr(parseStatus(statusTxt));
      setKnown(parseNetworks(netsTxt));
    } catch (err) {
      console.warn('refresh error:', err);
      setCurr(null);
      setKnown([]);
    }
  }, [creds, runPipeline]);

  /* Run once after creds load */
  useEffect(() => { refresh(); }, [creds, refresh]);

  /* 4️⃣  Scan for new networks, excluding known/current/AP SSIDs */
  const scanNetworks = useCallback(async () => {
    if (!creds) return;
    setScan([]);
    try {
      const scanOut = await runPipeline([
        '/sbin/wpa_cli -i wlan2 scan',
        'sleep 2',
        '/sbin/wpa_cli -i wlan2 scan_results',
      ]);

      // Gather SSIDs of our own APs (hostapd) to exclude
      let apTxt = '';
      try {
        apTxt = await runPipeline([
          `grep -h '^ssid=' /etc/hostapd/*.conf | cut -d= -f2`
        ]);
      } catch (_) { /* ignore if hostapd not present */ }

      const apSsids = apTxt.split('\n')
        .map(s => s.trim().toLowerCase())
        .filter(Boolean);

      const exclude = new Set([
        ...known.map(n => n.ssid.toLowerCase()),
        (curr?.ssid || '').toLowerCase(),
        ...apSsids,
      ]);

      // Build best-signal map per SSID
      const bySsid = new Map();
      scanOut.trim().split('\n').slice(1).forEach(line => { // skip header
        const cols   = line.split('\t');
        const ssid   = (cols[4] || '').trim();
        const signal = parseInt(cols[2], 10);
        if (!ssid) return;
        const key = ssid.toLowerCase();
        if (exclude.has(key)) return;
        const prev = bySsid.get(key);
        if (!prev || signal > prev.signal) {
          bySsid.set(key, { ssid, signal });
        }
      });

      setScan([...bySsid.values()].sort((a, b) => b.signal - a.signal));
    } catch (err) {
      console.warn('scanNetworks error:', err);
    }
  }, [creds, known, curr, runPipeline]);

  /* 5️⃣  Quick helpers: connect / forget / connect new */
  const connect = useCallback(async (id) => {
    if (!creds) return;
    await runPipeline([`/sbin/wpa_cli -i wlan2 select_network ${id}`]);
    refresh();
  }, [creds, refresh, runPipeline]);

  const forget = useCallback(async (id) => {
    if (!creds) return;
    await runPipeline([
      `/sbin/wpa_cli -i wlan2 remove_network ${id}`,
      `/sbin/wpa_cli -i wlan2 save_config`,
    ]);
    refresh();
  }, [creds, refresh, runPipeline]);

  const connectNew = useCallback(async (ssid, psk = '') => {
    if (!creds) return;
    try {
      const addOut = await runSSH({
        ...creds,
        command: '/sbin/wpa_cli -i wlan2 add_network',
      });
      const netId = addOut.trim();

      const cmds = [
        `/sbin/wpa_cli -i wlan2 set_network ${netId} ssid '"${ssid}"'`,
        psk
          ? `/sbin/wpa_cli -i wlan2 set_network ${netId} psk '"${psk}"'`
          : `/sbin/wpa_cli -i wlan2 set_network ${netId} key_mgmt NONE`,
        `/sbin/wpa_cli -i wlan2 enable_network ${netId}`,
        `/sbin/wpa_cli -i wlan2 select_network ${netId}`,
        `/sbin/wpa_cli -i wlan2 save_config`,
      ];
      await runPipeline(cmds);
    } catch (err) {
      console.warn('connectNew error:', err);
    } finally {
      setTimeout(refresh, 1000);   // let DHCP settle
      setScan([]);
    }
  }, [creds, refresh, runPipeline]);

  /* 6️⃣  Public API */
  return {
    creds,        // null until loaded
    curr,         // { ssid, ip_address, … } or null
    known,        // [{ id, ssid, selected }]
    scan,         // [{ ssid, signal }]
    refresh,
    scanNetworks,
    connect,
    forget,
    connectNew,
  };
}
