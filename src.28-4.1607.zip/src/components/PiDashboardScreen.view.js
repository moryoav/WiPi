import React from 'react';
import {
  View,
  Text,
  SectionList,
  TouchableOpacity,
  Modal,
  TextInput,
  Button,
  StyleSheet,
} from 'react-native';

export default function PiDashboardScreenView({
  hostname,
  curr,
  known = [],     // default to empty array
  scan  = [],     // default to empty array
  modalVisible,
  modalSsid,
  modalPsk,
  onScan,
  onConnect,
  onForget,
  onConnectNew,
  showModal,
  hideModal,
  onChangeModalPsk,
}) {
  // make sure data props are always arrays
  const sections = [
    {
      title: 'Known networks',
      data: Array.isArray(known) ? known : [],
      renderItem: ({ item }) => (
        <View style={styles.row}>
          <Text>{item.ssid || '(hidden)'}</Text>
          {item.selected && <Text style={styles.currentLabel}>CURRENT</Text>}
          <View style={styles.actionsRow}>
            <TouchableOpacity
              onPress={() => onConnect(item.id)}
              style={styles.actionButton}
            >
              <Text style={styles.connectText}>Connect</Text>
            </TouchableOpacity>
            <TouchableOpacity onPress={() => onForget(item.id)}>
              <Text style={styles.forgetText}>Forget</Text>
            </TouchableOpacity>
          </View>
        </View>
      ),
    },
    {
      title: 'New networks',
      data: Array.isArray(scan) ? scan : [],
      renderItem: ({ item }) => (
        <TouchableOpacity
          style={styles.row}
          onPress={() => showModal(item.ssid)}
        >
          <Text>{item.ssid}</Text>
          <Text style={styles.signalText}>Signal {item.signal}</Text>
        </TouchableOpacity>
      ),
    },
  ];

  return (
    <View style={styles.container}>
      <SectionList
        sections={sections}
        keyExtractor={(item, idx) => (item.id ?? item.ssid) + idx}
        ListHeaderComponent={
          <View style={styles.header}>
            <Text style={styles.title}>{hostname}</Text>
            {curr?.ssid && (
              <>
                <Text style={styles.subheading}>Current connection</Text>
                <View style={styles.currentRow}>
                  <Text>{curr.ssid}</Text>
                </View>
              </>
            )}
            <TouchableOpacity onPress={onScan} style={styles.scanButton}>
              <Text>🔍 Scan for new networks</Text>
            </TouchableOpacity>
          </View>
        }
        renderSectionHeader={({ section: { title } }) => (
          <Text style={styles.sectionHeader}>{title}</Text>
        )}
        stickySectionHeadersEnabled={false}
      />

      <Modal
        visible={modalVisible}
        transparent
        animationType="slide"
        onRequestClose={hideModal}
      >
        <View style={styles.modalOverlay}>
          <View style={styles.modalContent}>
            <Text style={styles.modalTitle}>Connect to "{modalSsid}"</Text>
            <TextInput
              placeholder="Password (leave blank if open)"
              secureTextEntry
              value={modalPsk}
              onChangeText={onChangeModalPsk}
              style={styles.modalInput}
            />
            <Button
              title="Connect"
              onPress={async () => {
                await onConnectNew(modalSsid, modalPsk);
                hideModal();
              }}
            />
            <View style={{ height: 8 }} />
            <Button title="Cancel" color="gray" onPress={hideModal} />
          </View>
        </View>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },

  header: { padding: 16 },
  title: { fontWeight: 'bold', marginBottom: 8 },
  subheading: { fontSize: 12, color: '#888' },
  currentRow: { padding: 12, borderWidth: 0.5, marginBottom: 16 },
  scanButton: {
    padding: 12,
    borderWidth: 0.5,
    backgroundColor: '#eee',
    alignItems: 'center',
    marginBottom: 12,
  },

  sectionHeader: {
    paddingLeft: 16,
    paddingTop: 8,
    fontSize: 12,
    color: '#888',
  },

  row: { padding: 12, borderBottomWidth: 0.5 },
  currentLabel: { fontSize: 12, color: 'green', marginTop: 4 },
  actionsRow: { flexDirection: 'row', marginTop: 4 },
  actionButton: { marginRight: 12 },
  connectText: { color: 'blue' },
  forgetText: { color: 'red' },
  signalText: { fontSize: 12, marginTop: 4 },

  modalOverlay: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'rgba(0,0,0,0.5)',
  },
  modalContent: {
    width: '80%',
    padding: 16,
    backgroundColor: '#fff',
    borderRadius: 8,
  },
  modalTitle: { marginBottom: 8 },
  modalInput: {
    borderWidth: 0.5,
    borderColor: '#ccc',
    padding: 8,
    marginBottom: 16,
    borderRadius: 4,
  },
});
